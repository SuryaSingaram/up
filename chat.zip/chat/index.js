// Setup basic express server
var express = require('express');
var app = express();
var path = require('path');
var server = require('http').createServer(app);
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/mydb";

// Routing
app.use(express.static(path.join(__dirname, 'public')));


var smileyMap = {
  "\u{1F600}": [":)", ":-)"],
  "\u{1F61F}": [":(", ":-("],
  "\u{1F44D}": ["((Y))", "((y))"],
  "\u{1F31E}": ["(surya)"],
  "\u{1F493}":["<3"]

};

var insertSmiley = function (smileys) {
  var replacements = [];
  Object.keys(smileys).forEach(function (file) {
    var _file = file;
    smileys[file].forEach(function (chars) {
      var reg = new RegExp(chars.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1"), "g");
      replacements.push([reg, _file]);
    });
  });
  return function (text) {
    return replacements.reduce(function (line, replacement) {
      return line.replace(replacement[0], replacement[1]);
    }, text);
  }
}(smileyMap);




var io = require('socket.io')(server);
var port = process.env.PORT || 3000;

server.listen(port, function () {
  console.log('Server listening at port %d', port);
});

// Routing
app.use(express.static(path.join(__dirname, 'public')));

// Chatroom
var numUsers = 0;
io.on('connection', function (socket) {
  //var addedUser = false;

  socket.on('new message', function (data) {
    console.log(data)
  var msg =insertSmiley(data.message)
  console.log(msg)
    var chat_detail = { room: data.room, message: msg }
    var roomName = data.room;
    socket.username = data.username;
    socket.room = data.room;

    console.log('room ' + roomName);
    console.log("socket.username:" + data.username);
    //send to db
    MongoClient.connect(url, function (err, db) {
      if (err) throw err;

      db.collection("chat_history").insertOne(chat_detail, function (err, res) {
        if (err) throw err;
        db.close();
      });
    });

    socket.join(roomName, function () {
      socket.broadcast.to(roomName).emit('new message', {
        username: data.username,
        message: msg
      })
    })
  });

  // when the client emits 'typing', we broadcast it to others
  socket.on('typing', function (data) {
    socket.join(socket.room, function () {
      socket.broadcast.to(socket.room).emit('typing', {
        username: socket.username,
        typing: data.typing
      })
    })
  });


  // when the user disconnects.. perform this
  socket.on('disconnect', function () {
    // echo globally that this client has left
    console.log('disconnected room : ' + socket.room);
    if (socket.room) {
      MongoClient.connect(url, function (err, db) {
        if (err) throw err;

        db.collection("chat_history").find({ room: socket.room }).toArray(function (err, result) {
          if (err) throw err;
          console.log(result);
          //send this chat history to particular API
          //code here ..
          //code here ..
          //code here ..
          // code here ..        
        });
      });
    }

  });
});